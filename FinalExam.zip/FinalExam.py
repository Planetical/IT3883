# Program Name: FinalExam.py
# Course: IT3883/Section W02
# Student Name: Adam Hutcheson
# Assignment Number: Final Exam
# Due Date: 12/11/2025

# Dictionary to reference when converting text to cents (values are stored as number of cents, not dollar values)
coin_values = {
    "penny": 1, "pennies": 1,
    "nickel": 5, "nickels": 5,
    "dime": 10, "dimes": 10,
    "quarter": 25, "quarters": 25
}

# Converting the text to dollar values and calculating total dollar value
def interpret(statement):
    text = statement.strip()
    phrases = text.split(' and ')

    total_cents = 0

    for phrase in phrases:
        words = phrase.strip().split()

        try:
            quantity = int(words[0])
        except ValueError:
            print(f"Error: '{words[0]}' is not a valid quantity")
            return None

        try:
            denomination = coin_values[words[1]]
        except KeyError:
            print(f"Error: '{words[1]}' is not a valid denomination")
            return None

        total_cents += quantity * denomination

    return total_cents / 100

# User input
user_input = input("Enter the coins: ")

# Calling interpret method
result = interpret(user_input)

# Print the dollar value if there are no errors. Round to 2
if result is not None:
    print(f"Total: ${result:.2f}")